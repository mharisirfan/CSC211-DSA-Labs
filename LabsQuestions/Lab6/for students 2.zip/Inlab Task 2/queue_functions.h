void q_insert(struct node ** qrear, struct node ** qfront, struct element new_data);
struct element q_delete(struct node ** qfront);
struct element q_peek(struct node ** qfront);
int q_isEmpty(struct node ** qfront);

