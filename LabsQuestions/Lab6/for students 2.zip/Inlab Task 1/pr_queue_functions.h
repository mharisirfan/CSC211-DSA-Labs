void pr_enqueue(struct node ** qrear, struct node ** qfront, struct element new_data, int priority);
struct element pr_dequeue(struct node ** qfront);
int pr_isEmpty(struct node ** qfront);

