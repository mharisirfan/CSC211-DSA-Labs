
struct element pop(struct node ** top);
void push(struct node ** top, struct element new_data);
bool isStackEmpty(struct node ** top);
